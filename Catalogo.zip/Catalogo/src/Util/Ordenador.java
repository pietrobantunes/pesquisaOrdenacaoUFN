package Util;

import java.util.ArrayList;
import java.util.Comparator;
import model.Produto;

public class Ordenador {

    public static long limiteNanos = 0;
    public static boolean interrompido = false;

    // comparadores
    public static final Comparator<Produto> POR_ID = new Comparator<Produto>() {
        @Override
        public int compare(Produto p1, Produto p2) {
            return Integer.compare(p1.getId(), p2.getId());
        }
    };

    public static final Comparator<Produto> POR_NOME = new Comparator<Produto>() {
        @Override
        public int compare(Produto p1, Produto p2) {
            return p1.getNome().compareToIgnoreCase(p2.getNome());
        }
    };

    public static final Comparator<Produto> POR_CATEGORIA = new Comparator<Produto>() {
        @Override
        public int compare(Produto p1, Produto p2) {
            return p1.getCategoria().compareToIgnoreCase(p2.getCategoria());
        }
    };

    public static final Comparator<Produto> POR_PRECO = new Comparator<Produto>() {
        @Override
        public int compare(Produto p1, Produto p2) {
            return Double.compare(p1.getPreco(), p2.getPreco());
        }
    };

    public static final Comparator<Produto> POR_ESTOQUE = new Comparator<Produto>() {
        @Override
        public int compare(Produto p1, Produto p2) {
            return Integer.compare(p1.getEstoque(), p2.getEstoque());
        }
    };

    // bolha
    public static ArrayList<Float> bolha(ArrayList<Produto> lista, Comparator<Produto> comparador) {

        ArrayList<Float> metricas = new ArrayList<>();

        long inicio = System.nanoTime();
        interrompido = false;

        long qtdComparacoes = 0;
        long qtdTrocas = 0;
        int i, j;
        Produto aux;
        boolean trocou;

        for (i = 0; i < lista.size() - 1; i++) {
            if (limiteNanos > 0 && System.nanoTime() - inicio > limiteNanos) {
                interrompido = true;
                break;
            }
            trocou = false;
            for (j = 0; j < lista.size() - 1 - i; j++) {
                qtdComparacoes++;
                if (comparador.compare(lista.get(j), lista.get(j + 1)) > 0) {
                    aux = lista.get(j);
                    lista.set(j, lista.get(j + 1));
                    lista.set(j + 1, aux);
                    qtdTrocas++;
                    trocou = true;
                }
            }
            if (!trocou) {
                break;
            }
        }

        metricas.add((float) qtdComparacoes);
        metricas.add((float) qtdTrocas);
        return metricas;
    }

    // seleção
    public static ArrayList<Float> selecao(ArrayList<Produto> lista, Comparator<Produto> comparador) {

        ArrayList<Float> metricas = new ArrayList<>();

        long inicio = System.nanoTime();
        interrompido = false;

        long qtdComparacoes = 0;
        long qtdTrocas = 0;
        int i, j, posMenor;
        Produto aux;

        for (i = 0; i < lista.size() - 1; i++) {
            if (limiteNanos > 0 && System.nanoTime() - inicio > limiteNanos) {
                interrompido = true;
                break;
            }
            posMenor = i;
            for (j = i + 1; j < lista.size(); j++) {
                qtdComparacoes++;
                if (comparador.compare(lista.get(j), lista.get(posMenor)) < 0) {
                    posMenor = j;
                }
            }
            if (posMenor != i) {
                aux = lista.get(i);
                lista.set(i, lista.get(posMenor));
                lista.set(posMenor, aux);
                qtdTrocas++;
            }
        }

        metricas.add((float) qtdComparacoes);
        metricas.add((float) qtdTrocas);
        return metricas;
    }

    // merge sort
    public static ArrayList<Float> merge(ArrayList<Produto> lista, Comparator<Produto> comparador) {

        ArrayList<Float> metricas = new ArrayList<>();

        long qtdComparacoes = 0;
        long qtdTrocas = 0;
        int n = lista.size();
        int tamanho, ini, meio, fim, i, j, k;
        ArrayList<Produto> aux = new ArrayList<>(lista);

        for (tamanho = 1; tamanho < n; tamanho = tamanho * 2) {
            for (ini = 0; ini < n - tamanho; ini = ini + 2 * tamanho) {
                meio = ini + tamanho - 1;
                fim = Math.min(ini + 2 * tamanho - 1, n - 1);

                for (k = ini; k <= fim; k++) {
                    aux.set(k, lista.get(k));
                }

                i = ini;
                j = meio + 1;
                k = ini;

                while (i <= meio && j <= fim) {
                    qtdComparacoes++;
                    if (comparador.compare(aux.get(i), aux.get(j)) <= 0) {
                        lista.set(k, aux.get(i));
                        i++;
                    } else {
                        lista.set(k, aux.get(j));
                        j++;
                    }
                    qtdTrocas++;
                    k++;
                }

                while (i <= meio) {
                    lista.set(k, aux.get(i));
                    qtdTrocas++;
                    i++;
                    k++;
                }

                while (j <= fim) {
                    lista.set(k, aux.get(j));
                    qtdTrocas++;
                    j++;
                    k++;
                }
            }
        }

        metricas.add((float) qtdComparacoes);
        metricas.add((float) qtdTrocas);
        return metricas;
    }
}
