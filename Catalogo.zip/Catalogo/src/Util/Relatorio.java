package Util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;

public class Relatorio {

    public static final String ARQUIVO       = "relatorio.txt";
    public static final String NAO_CONCLUIDO = "não concluído (> 2 min)";

    public static final String ORDENACAO_SIMPLES   = "Ordenação simples (por preço)";
    public static final String ORDENACAO_EFICIENTE = "Ordenação eficiente (por preço)";
    public static final String BUSCA_LINEAR        = "Busca linear por id (média)";
    public static final String BUSCA_BINARIA       = "Busca binária por id (média)";
    public static final String BUSCA_HASH          = "Busca por HashMap (média)";
    public static final String CONSTRUCAO_HASH     = "Construção do HashMap";

    private static final String[] OPERACOES = {
        ORDENACAO_SIMPLES, ORDENACAO_EFICIENTE,
        BUSCA_LINEAR, BUSCA_BINARIA, BUSCA_HASH, CONSTRUCAO_HASH
    };
    private static final String[] COLUNAS = {"1.000", "10.000", "50.000"};

    // registrar valor
    public static boolean registrar(String operacao, int qtdRegistros, String valor) {
        int coluna = coluna(qtdRegistros);
        int linha  = linha(operacao);
        if (coluna < 0 || linha < 0) {
            return false;
        }

        String[][] valores = celulasVazias();
        lerArquivo(valores);
        valores[linha][coluna] = valor;
        return gravar(valores);
    }

    private static int coluna(int qtdRegistros) {
        switch (qtdRegistros) {
            case 1000:  return 0;
            case 10000: return 1;
            case 50000: return 2;
            default:    return -1;
        }
    }

    private static int linha(String operacao) {
        for (int l = 0; l < OPERACOES.length; l++) {
            if (OPERACOES[l].equals(operacao)) {
                return l;
            }
        }
        return -1;
    }

    private static String[][] celulasVazias() {
        String[][] v = new String[OPERACOES.length][COLUNAS.length];
        for (int l = 0; l < OPERACOES.length; l++) {
            for (int c = 0; c < COLUNAS.length; c++) {
                v[l][c] = "";
            }
        }
        return v;
    }

    // leitura do arquivo existente
    private static void lerArquivo(String[][] valores) {
        File arquivo = new File(ARQUIVO);
        if (!arquivo.exists()) {
            return;
        }

        try (BufferedReader leitor = new BufferedReader(new FileReader(arquivo, StandardCharsets.UTF_8))) {
            String linha;
            while ((linha = leitor.readLine()) != null) {
                if (linha.startsWith("|") && !linha.contains("---")) {
                    String[] celulas = linha.split("\\|", -1);
                    if (celulas.length >= 5) {
                        int l = linha(celulas[1].trim());
                        if (l >= 0) {
                            for (int c = 0; c < COLUNAS.length; c++) {
                                String val = celulas[c + 2].trim();
                                if (!val.isEmpty()) {
                                    valores[l][c] = val;
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // gravação
    private static boolean gravar(String[][] valores) {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ARQUIVO, StandardCharsets.UTF_8))) {
            escritor.write("# Relatório de Desempenho - Pesquisa e Ordenação");
            escritor.newLine();
            escritor.newLine();

            escritor.write(String.format("| %-32s | %-16s | %-16s | %-16s |", "Operação", COLUNAS[0], COLUNAS[1], COLUNAS[2]));
            escritor.newLine();
            escritor.write("|:---------------------------------|:----------------:|:----------------:|:----------------:|");
            escritor.newLine();

            for (int l = 0; l < OPERACOES.length; l++) {
                escritor.write(String.format("| %-32s | %-16s | %-16s | %-16s |",
                        OPERACOES[l],
                        valores[l][0].isEmpty() ? "-" : valores[l][0],
                        valores[l][1].isEmpty() ? "-" : valores[l][1],
                        valores[l][2].isEmpty() ? "-" : valores[l][2]));
                escritor.newLine();
            }

            escritor.newLine();
            escritor.write("## Análise");
            escritor.newLine();
            escritor.write("A busca por HashMap foi a mais rápida por operar em tempo médio O(1) via acesso direto por chave.");
            escritor.newLine();
            escritor.write("Vale a pena construir o HashMap quando são realizadas múltiplas buscas na base, compensando o custo");
            escritor.newLine();
            escritor.write("inicial O(n) da indexação com consultas subsequentes praticamente instantâneas.");
            escritor.newLine();

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // leitura do texto completo
    public static String lerTexto() {
        File arquivo = new File(ARQUIVO);
        if (!arquivo.exists()) {
            return "Nenhuma operação registrada ainda.";
        }
        StringBuilder texto = new StringBuilder();
        try (BufferedReader leitor = new BufferedReader(new FileReader(arquivo, StandardCharsets.UTF_8))) {
            String linha;
            while ((linha = leitor.readLine()) != null) {
                texto.append(linha).append("\n");
            }
        } catch (Exception e) {
            return "Problemas ao ler " + ARQUIVO;
        }
        return texto.toString();
    }
}
