package Util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import model.Produto;

public class Utilidades {

    public static String cabecalho = "id;nome;categoria;preco;estoque";

    // leitura do arquivo
    public static boolean carregarArquivoEmLista(String nomeArquivo, ArrayList<Produto> lista) {
        try {
            BufferedReader leitor = new BufferedReader(
                    new FileReader(nomeArquivo, StandardCharsets.UTF_8));
            String linha;

            linha = leitor.readLine();
            if (linha != null) {
                cabecalho = linha;
            }

            do {
                linha = leitor.readLine();
                if (linha != null && !linha.isBlank()) {
                    lista.add(montarProduto(linha));
                }
            } while (linha != null);

            leitor.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static Produto montarProduto(String linha) {
        Produto p = new Produto();
        String[] campos = linha.split(";");

        p.setId(Integer.parseInt(campos[0].trim()));
        p.setNome(campos[1].trim());
        p.setCategoria(campos[2].trim());
        p.setPreco(Double.parseDouble(campos[3].trim().replace(",", ".")));
        p.setEstoque(Integer.parseInt(campos[4].trim()));

        return p;
    }

    // escrita do arquivo
    public static boolean exportarListaEmArquivo(String nomeArquivo, ArrayList<Produto> lista) {
        try {
            BufferedWriter escritor = new BufferedWriter(
                    new FileWriter(nomeArquivo, StandardCharsets.UTF_8));

            escritor.write(cabecalho);
            escritor.newLine();

            for (Produto p : lista) {
                escritor.write(montarLinha(p));
                escritor.newLine();
            }

            escritor.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static String montarLinha(Produto p) {
        return p.getId() + ";"
                + p.getNome() + ";"
                + p.getCategoria() + ";"
                + String.format(Locale.US, "%.2f", p.getPreco()) + ";"
                + p.getEstoque();
    }

    public static void exibirLista(ArrayList<Produto> lista) {
        for (Produto item : lista) {
            System.out.println(item);
        }
        System.out.println("--------------------------");
        System.out.println("Total de registros: " + lista.size());
    }
}
