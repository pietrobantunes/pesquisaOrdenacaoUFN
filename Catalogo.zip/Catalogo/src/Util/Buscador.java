package Util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import model.Produto;

public class Buscador {

    public static final int REPETICOES = 1000;

    public static HashMap<Integer, Produto>      indiceId        = new HashMap<>();
    public static HashMap<String, List<Produto>> indiceCategoria = new HashMap<>();

    // busca linear
    public static ArrayList<Float> buscaLinear(int id, ArrayList<Produto> lista) {

        ArrayList<Float> metricas = new ArrayList<>();

        long qtdComparacoes = 0;
        int posicao = -1;

        for (int i = 0; i < lista.size(); i++) {
            qtdComparacoes++;
            if (lista.get(i).getId() == id) {
                posicao = i;
                break;
            }
        }

        metricas.add((float) qtdComparacoes);
        metricas.add((float) posicao);
        return metricas;
    }

    // busca binária
    public static ArrayList<Float> pesquisaBinaria(int id, ArrayList<Produto> lista) {

        ArrayList<Float> metricas = new ArrayList<>();

        int ini = 0;
        int fim = lista.size() - 1;
        int posicao = -1;
        long qtdComparacoes = 0;

        while (ini <= fim) {
            int meio = (ini + fim) / 2;
            qtdComparacoes++;

            if (lista.get(meio).getId() == id) {
                posicao = meio;
                break;
            } else if (lista.get(meio).getId() < id) {
                ini = meio + 1;
            } else {
                fim = meio - 1;
            }
        }

        metricas.add((float) qtdComparacoes);
        metricas.add((float) posicao);
        return metricas;
    }

    // HashMap de id
    public static double montarIndiceIdComTempo(ArrayList<Produto> lista) {
        long inicio = System.nanoTime();
        indiceId = new HashMap<>();
        for (Produto p : lista) {
            indiceId.put(p.getId(), p);
        }
        return (System.nanoTime() - inicio) / 1_000_000.0;
    }

    public static void montarIndiceId(ArrayList<Produto> lista) {
        montarIndiceIdComTempo(lista);
    }

    // HashMap de categoria
    public static void montarIndiceCategoria(ArrayList<Produto> lista) {
        indiceCategoria = new HashMap<>();
        for (Produto p : lista) {
            String chave = p.getCategoria().toLowerCase();
            if (!indiceCategoria.containsKey(chave)) {
                indiceCategoria.put(chave, new ArrayList<>());
            }
            indiceCategoria.get(chave).add(p);
        }
    }

    // consultas
    public static Produto buscaHash(int id) {
        return indiceId.get(id);
    }

    public static List<Produto> listarPorCategoria(String categoria) {
        List<Produto> resultado = indiceCategoria.get(categoria.trim().toLowerCase());
        return resultado != null ? resultado : new ArrayList<>();
    }
}
