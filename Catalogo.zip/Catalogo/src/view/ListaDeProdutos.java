package view;

import Util.Buscador;
import Util.Ordenador;
import Util.Relatorio;
import Util.Utilidades;
import java.awt.Cursor;
import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;
import model.Produto;

public class ListaDeProdutos extends javax.swing.JFrame {

    ArrayList<Produto> listaProduto = new ArrayList<>();
    boolean ordenadaPorId = false;

    public ListaDeProdutos() {
        initComponents();
        setLocationRelativeTo(null);
    }

    public void carregarTabela(List<Produto> lista) {
        DefaultTableModel tabela = (DefaultTableModel) tblProdutos.getModel();
        tabela.setRowCount(0);
        for (Produto p : lista) {
            tabela.addRow(new Object[]{
                p.getId(),
                p.getNome(),
                p.getCategoria(),
                String.format("%.2f", p.getPreco()),
                p.getEstoque()
            });
        }
    }

    private Comparator<Produto> comparadorSelecionado(String criterio) {
        switch (criterio) {
            case "ID":        return Ordenador.POR_ID;
            case "Nome":      return Ordenador.POR_NOME;
            case "Preço":     return Ordenador.POR_PRECO;
            case "Categoria": return Ordenador.POR_CATEGORIA;
            default:          return null;
        }
    }

    private String registrar(String operacao, String valor) {
        if (Relatorio.registrar(operacao, listaProduto.size(), valor)) {
            return " | registrado no relatório";
        }
        return " | não vai para o relatório (use os arquivos de 1.000, 10.000 ou 50.000)";
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtarquivo = new javax.swing.JTextField();
        btnprocurar = new javax.swing.JButton();
        btnExportar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        cmbordenacao = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        cmbcriterio = new javax.swing.JComboBox();
        btnordenar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        cmbBusca = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        txtBusca = new javax.swing.JTextField();
        btnprocurar1 = new javax.swing.JButton();
        btnListarTodos = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProdutos = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        TxtComparacoes = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        TxtTrocas = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        TxtTempo = new javax.swing.JLabel();
        btnRelatorio = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Catálogo de Produtos");
        setBackground(new java.awt.Color(228, 228, 228));
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Arquivo:");

        txtarquivo.setEditable(false);

        btnprocurar.setText("Abrir");
        btnprocurar.addActionListener(this::btnprocurarActionPerformed);

        btnExportar.setText("Exportar");
        btnExportar.addActionListener(this::btnExportarActionPerformed);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Ordenação:");

        cmbordenacao.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Bolha", "Seleção", "Merge" }));
        cmbordenacao.addActionListener(this::cmbordenacaoActionPerformed);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setText("Critério:");

        cmbcriterio.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "ID", "Nome", "Preço", "Categoria" }));

        btnordenar.setText("Ordenar");
        btnordenar.addActionListener(this::btnordenarActionPerformed);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Busca:");

        cmbBusca.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Linear (ID)", "Binária (ID)", "HashMap (ID)", "Categoria (HashMap)" }));
        cmbBusca.addActionListener(this::cmbBuscaActionPerformed);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("ID/Categoria:");

        txtBusca.addActionListener(this::txtBuscaActionPerformed);

        btnprocurar1.setText("Buscar");
        btnprocurar1.addActionListener(this::btnprocurar1ActionPerformed);

        btnListarTodos.setText("Recarregar");
        btnListarTodos.addActionListener(this::btnListarTodosActionPerformed);

        tblProdutos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome", "Categoria", "Preço", "Estoque"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblProdutos);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("Comparações:");

        TxtComparacoes.setText("-");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Trocas:");

        TxtTrocas.setText("-");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setText("Tempo:");

        TxtTempo.setText("-");

        btnRelatorio.setText("Visualizar Relatório");
        btnRelatorio.addActionListener(this::btnRelatorioActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TxtTempo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtarquivo, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnprocurar)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnExportar))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(cmbordenacao, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cmbcriterio, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnordenar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(cmbBusca, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtBusca, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnprocurar1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnListarTodos))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(TxtComparacoes, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(TxtTrocas, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 162, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtarquivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnprocurar)
                    .addComponent(btnExportar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cmbordenacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(cmbcriterio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnordenar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cmbBusca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txtBusca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnprocurar1)
                    .addComponent(btnListarTodos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(TxtComparacoes))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(TxtTrocas))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(TxtTempo))
                        .addContainerGap(16, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnRelatorio)
                        .addContainerGap())))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnprocurarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprocurarActionPerformed
        JFileChooser fc = new JFileChooser(System.getProperty("user.dir"));
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        String caminho = fc.getSelectedFile().getAbsolutePath();
        listaProduto.clear();

        long inicio = System.nanoTime();
        boolean carregou = Utilidades.carregarArquivoEmLista(caminho, listaProduto);
        double tempoLeitura = (System.nanoTime() - inicio) / 1_000_000.0;

        if (!carregou) {
            JOptionPane.showMessageDialog(this, "Problemas ao carregar o arquivo", "Atenção", JOptionPane.ERROR_MESSAGE);
            return;
        }

        ordenadaPorId = false;
        txtarquivo.setText(caminho);
        carregarTabela(listaProduto);

        TxtComparacoes.setText("-");
        TxtTrocas.setText("-");

        double tempoHash = Buscador.montarIndiceIdComTempo(listaProduto);

        long inicioCategoria = System.nanoTime();
        Buscador.montarIndiceCategoria(listaProduto);
        double tempoCategoria = (System.nanoTime() - inicioCategoria) / 1_000_000.0;

        String valorHash = String.format("%.3f ms", tempoHash);
        registrar(Relatorio.CONSTRUCAO_HASH, valorHash);

        TxtTempo.setText(String.format("leitura %.3f ms | HashMap id %.3f ms | índice categoria %.3f ms",
                tempoLeitura, tempoHash, tempoCategoria));
    }//GEN-LAST:event_btnprocurarActionPerformed

    private void btnExportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportarActionPerformed
        if (listaProduto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Carregue um arquivo antes de exportar", "Atenção", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JFileChooser fc = new JFileChooser(System.getProperty("user.dir"));
        fc.setSelectedFile(new File("produtos_exportados.txt"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        if (Utilidades.exportarListaEmArquivo(fc.getSelectedFile().getAbsolutePath(), listaProduto)) {
            JOptionPane.showMessageDialog(this, "Lista exportada em " + fc.getSelectedFile().getName(), "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Problemas ao exportar o arquivo", "Atenção", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnExportarActionPerformed

    private void btnordenarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnordenarActionPerformed
        if (listaProduto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Carregue o arquivo antes de ordenar", "Atenção", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String metodo = (String) cmbordenacao.getSelectedItem();
        String criterio = (String) cmbcriterio.getSelectedItem();
        Comparator<Produto> comparador = comparadorSelecionado(criterio);

        if (comparador == null) {
            JOptionPane.showMessageDialog(this, "Selecione o critério", "Atenção", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!metodo.equals("Merge") && listaProduto.size() > 10000) {
            int resposta = JOptionPane.showConfirmDialog(this,
                    metodo + " com " + listaProduto.size() + " registros pode levar alguns segundos. Continuar?",
                    "Atenção", JOptionPane.YES_NO_OPTION);
            if (resposta != JOptionPane.YES_OPTION) {
                return;
            }
        }

        ArrayList<Float> metricas;
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        long inicio = System.nanoTime();
        Ordenador.limiteNanos = 120_000_000_000L;

        switch (metodo) {
            case "Bolha":
                metricas = Ordenador.bolha(listaProduto, comparador);
                break;
            case "Seleção":
                metricas = Ordenador.selecao(listaProduto, comparador);
                break;
            case "Merge":
                metricas = Ordenador.merge(listaProduto, comparador);
                break;
            default:
                setCursor(Cursor.getDefaultCursor());
                JOptionPane.showMessageDialog(this, "Selecione um método de ordenação", "Atenção", JOptionPane.ERROR_MESSAGE);
                return;
        }

        double tempoMs = (System.nanoTime() - inicio) / 1_000_000.0;
        setCursor(Cursor.getDefaultCursor());

        boolean interrompeu = Ordenador.interrompido;
        Ordenador.limiteNanos = 0;
        Ordenador.interrompido = false;

        ordenadaPorId = criterio.equals("ID") && !interrompeu;

        TxtComparacoes.setText(String.valueOf(metricas.get(0).longValue()));
        TxtTrocas.setText(String.valueOf(metricas.get(1).longValue()));
        TxtTempo.setText(String.format("%.3f ms", tempoMs));

        String valor = String.format("%.3f ms (%s)", tempoMs, metodo);
        if (interrompeu) {
            valor = Relatorio.NAO_CONCLUIDO + " (" + metodo + ")";
            TxtTempo.setText(Relatorio.NAO_CONCLUIDO);
            JOptionPane.showMessageDialog(this, metodo + " passou de 2 minutos e foi interrompido.\nA lista ficou só parcialmente ordenada.", "Atenção", JOptionPane.WARNING_MESSAGE);
        }

        String registro = " | não vai para o relatório (só ordenação por preço)";
        if (criterio.equals("Preço")) {
            String operacao = metodo.equals("Merge") ? Relatorio.ORDENACAO_EFICIENTE : Relatorio.ORDENACAO_SIMPLES;
            registro = registrar(operacao, valor);
        }
        carregarTabela(listaProduto);
    }//GEN-LAST:event_btnordenarActionPerformed

    private void txtBuscaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscaActionPerformed
        btnprocurar1ActionPerformed(evt);
    }//GEN-LAST:event_txtBuscaActionPerformed

    private void btnprocurar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprocurar1ActionPerformed
        if (listaProduto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Carregue o arquivo antes de buscar", "Atenção", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String tecnica = (String) cmbBusca.getSelectedItem();
        String texto = txtBusca.getText().trim();

        if (texto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o id ou a categoria", "Atenção", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int repeticoes = Buscador.REPETICOES;
        long inicio;
        double tempoMedio;

        if (tecnica.equals("Categoria (HashMap)")) {
            List<Produto> resultado = null;
            inicio = System.nanoTime();
            for (int r = 0; r < repeticoes; r++) {
                resultado = Buscador.listarPorCategoria(texto);
            }
            tempoMedio = (System.nanoTime() - inicio) / 1_000_000.0 / repeticoes;

            TxtComparacoes.setText("-");
            TxtTrocas.setText("-");
            TxtTempo.setText(String.format("%.6f ms (média de %d buscas)", tempoMedio, repeticoes));

            if (resultado.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Categoria \"" + texto + "\" não encontrada", "Atenção", JOptionPane.WARNING_MESSAGE);
            } else {
                carregarTabela(resultado);
            }
            return;
        }

        int id;
        try {
            id = Integer.parseInt(texto);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Informe um id numérico", "Atenção", JOptionPane.ERROR_MESSAGE);
            return;
        }

        ArrayList<Float> metricas = null;
        Produto encontrado = null;

        if (tecnica.equals("Linear (id)")) {
            inicio = System.nanoTime();
            for (int r = 0; r < repeticoes; r++) {
                metricas = Buscador.buscaLinear(id, listaProduto);
            }
            tempoMedio = (System.nanoTime() - inicio) / 1_000_000.0 / repeticoes;
        } else if (tecnica.equals("Binária (id)")) {
            if (!ordenadaPorId) {
                JOptionPane.showMessageDialog(this, "A busca binária exige a lista ordenada por ID.\nOrdene por ID antes de buscar.", "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            inicio = System.nanoTime();
            for (int r = 0; r < repeticoes; r++) {
                metricas = Buscador.pesquisaBinaria(id, listaProduto);
            }
            tempoMedio = (System.nanoTime() - inicio) / 1_000_000.0 / repeticoes;
        } else {
            inicio = System.nanoTime();
            for (int r = 0; r < repeticoes; r++) {
                encontrado = Buscador.buscaHash(id);
            }
            tempoMedio = (System.nanoTime() - inicio) / 1_000_000.0 / repeticoes;
        }

        if (metricas != null) {
            int posicao = metricas.get(1).intValue();
            if (posicao >= 0) {
                encontrado = listaProduto.get(posicao);
            }
            TxtComparacoes.setText(String.valueOf(metricas.get(0).longValue()));
        } else {
            TxtComparacoes.setText("-");
        }
        TxtTrocas.setText("-");
        TxtTempo.setText(String.format("%.6f ms (média de %d buscas)", tempoMedio, repeticoes));

        if (encontrado == null) {
            JOptionPane.showMessageDialog(this, "Produto com id " + id + " não encontrado", "Atenção", JOptionPane.WARNING_MESSAGE);
        } else {
            ArrayList<Produto> resultado = new ArrayList<>();
            resultado.add(encontrado);
            carregarTabela(resultado);
            String operacao;
            if (tecnica.equals("Linear (id)")) {
                operacao = Relatorio.BUSCA_LINEAR;
            } else if (tecnica.equals("Binária (id)")) {
                operacao = Relatorio.BUSCA_BINARIA;
            } else {
                operacao = Relatorio.BUSCA_HASH;
            }
        }
    }//GEN-LAST:event_btnprocurar1ActionPerformed

    private void btnListarTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarTodosActionPerformed
        carregarTabela(listaProduto);
    }//GEN-LAST:event_btnListarTodosActionPerformed

    private void btnRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRelatorioActionPerformed
        JTextArea texto = new JTextArea(Relatorio.lerTexto(), 18, 90);
        texto.setEditable(false);
        texto.setFont(new java.awt.Font(java.awt.Font.MONOSPACED, java.awt.Font.PLAIN, 12));
        JOptionPane.showMessageDialog(this, new JScrollPane(texto),
                "Relatório – " + new File(Relatorio.ARQUIVO).getAbsolutePath(), JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_btnRelatorioActionPerformed

    private void cmbordenacaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbordenacaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbordenacaoActionPerformed

    private void cmbBuscaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbBuscaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbBuscaActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
        }

        java.awt.EventQueue.invokeLater(() -> new ListaDeProdutos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TxtComparacoes;
    private javax.swing.JLabel TxtTempo;
    private javax.swing.JLabel TxtTrocas;
    private javax.swing.JButton btnExportar;
    private javax.swing.JButton btnListarTodos;
    private javax.swing.JButton btnRelatorio;
    private javax.swing.JButton btnordenar;
    private javax.swing.JButton btnprocurar;
    private javax.swing.JButton btnprocurar1;
    private javax.swing.JComboBox cmbBusca;
    private javax.swing.JComboBox cmbcriterio;
    private javax.swing.JComboBox cmbordenacao;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblProdutos;
    private javax.swing.JTextField txtBusca;
    private javax.swing.JTextField txtarquivo;
    // End of variables declaration//GEN-END:variables
}
