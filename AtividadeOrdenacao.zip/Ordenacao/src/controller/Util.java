package controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class Util {

    public static boolean carregarArquivoDaLista(String nomeArquivo, ArrayList<Integer> Lista) {
        try {
            FileReader procurador;
            procurador = new FileReader(nomeArquivo);
            BufferedReader leitor = new BufferedReader(procurador);
            String linha;
            do {
                linha = leitor.readLine();
                if (linha != null) {
                    Lista.add(Integer.parseInt(linha));
                }
            } while (linha != null);
            leitor.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
